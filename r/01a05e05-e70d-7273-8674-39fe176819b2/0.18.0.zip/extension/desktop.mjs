// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/host.js
var ExtensionError = class extends Error {
  kind;
  constructor(message, kind) {
    super(message);
    this.kind = kind;
    this.name = "ExtensionError";
  }
};
async function* readLines(reader) {
  const decoder = new TextDecoder();
  let buffered = "";
  try {
    for (; ; ) {
      const { done, value } = await reader.read();
      if (done)
        break;
      buffered += decoder.decode(value, { stream: true });
      for (let cut = buffered.indexOf("\n"); cut >= 0; cut = buffered.indexOf("\n")) {
        const line = buffered.slice(0, cut);
        buffered = buffered.slice(cut + 1);
        if (line.trim().length > 0)
          yield line;
      }
    }
    buffered += decoder.decode();
    if (buffered.trim().length > 0)
      yield buffered;
  } finally {
    reader.releaseLock();
  }
}
var LineWriter = class {
  writer;
  encoder = new TextEncoder();
  tail = Promise.resolve();
  constructor(writable) {
    this.writer = writable.getWriter();
  }
  write(message) {
    const chunk = this.encoder.encode(`${JSON.stringify(message)}
`);
    const written = this.tail.then(() => this.writer.write(chunk));
    this.tail = written.catch(() => void 0);
    return written;
  }
  async close() {
    await this.tail;
    try {
      await this.writer.close();
    } catch {
      this.writer.releaseLock();
    }
  }
};

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/deno.js
function denoHost() {
  const runtime = globalThis.Deno;
  if (!runtime) {
    throw new ExtensionError("extensions run under deno; no Deno global in this process", "no-runtime");
  }
  return {
    readable: runtime.stdin.readable,
    writable: runtime.stdout.writable,
    exit: (code) => runtime.exit(code)
  };
}

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/message.js
function json(data) {
  return { encoding: "json", data };
}
function asJson(message) {
  return message.encoding === "json" ? message.data : void 0;
}
var CHUNK = 32768;
function toBase64(bytes) {
  let latin1 = "";
  for (let i = 0; i < bytes.length; i += CHUNK) {
    latin1 += String.fromCharCode(...bytes.subarray(i, i + CHUNK));
  }
  return btoa(latin1);
}
function fromBase64(data) {
  const latin1 = atob(data);
  const bytes = new Uint8Array(latin1.length);
  for (let i = 0; i < latin1.length; i++)
    bytes[i] = latin1.charCodeAt(i);
  return bytes;
}
function intoWire(message) {
  if (typeof message === "string")
    return { encoding: "text", data: message };
  if (message instanceof Uint8Array)
    return { encoding: "binary", data: toBase64(message) };
  if (message.encoding === "binary")
    return { encoding: "binary", data: toBase64(message.data) };
  return message;
}
function fromWire(message) {
  if (message.encoding === "binary")
    return { encoding: "binary", data: fromBase64(message.data) };
  return message;
}

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/protocol.js
var EXTENSION_API_VERSION = 1;

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/runtime.js
function describe(value) {
  if (typeof value === "string")
    return value;
  if (value instanceof Error)
    return value.stack ?? `${value.name}: ${value.message}`;
  try {
    return JSON.stringify(value) ?? String(value);
  } catch {
    return String(value);
  }
}
var DeviceImpl = class {
  id;
  runtime;
  name = "";
  active = false;
  connected = false;
  config = {};
  constructor(id, runtime) {
    this.id = id;
    this.runtime = runtime;
  }
  send(message) {
    this.runtime.forward(this.id, message);
  }
};
var ExtensionRuntime = class {
  spec;
  host;
  writer;
  devices_ = /* @__PURE__ */ new Map();
  pending = /* @__PURE__ */ new Map();
  onDevice = /* @__PURE__ */ new Set();
  onMessage = /* @__PURE__ */ new Set();
  onConfig = /* @__PURE__ */ new Set();
  nextRequestId = 1;
  started = false;
  finishing;
  settled;
  helloApi = EXTENSION_API_VERSION;
  helloWebapp = { id: "", name: "", version: "" };
  helloDataDir = "";
  reader;
  constructor(spec, host) {
    this.spec = spec;
    this.host = host;
    this.writer = new LineWriter(host.writable);
  }
  get api() {
    return this.helloApi;
  }
  get webapp() {
    return this.helloWebapp;
  }
  get dataDir() {
    return this.helloDataDir;
  }
  get devices() {
    return [...this.devices_.values()].filter((device) => device.connected);
  }
  device(id) {
    return this.ensure(id);
  }
  broadcast(message) {
    this.forward(void 0, message);
  }
  config(device) {
    const id = typeof device === "string" ? device : device.id;
    return this.devices_.get(id)?.config ?? {};
  }
  on(event, listener) {
    if (event === "device") {
      const fn2 = listener;
      this.onDevice.add(fn2);
      return () => this.onDevice.delete(fn2);
    }
    if (event === "message") {
      const fn2 = listener;
      this.onMessage.add(fn2);
      return () => this.onMessage.delete(fn2);
    }
    const fn = listener;
    this.onConfig.add(fn);
    return () => this.onConfig.delete(fn);
  }
  kv = {
    get: (key) => this.request((id) => ({ t: "kv.get", id, key })).then((value) => value === null ? void 0 : value),
    set: (key, value) => this.request((id) => ({ t: "kv.set", id, key, value })).then(() => void 0),
    delete: (key) => this.request((id) => ({ t: "kv.delete", id, key })).then(() => void 0),
    list: () => this.request((id) => ({ t: "kv.list", id })).then((value) => value ?? [])
  };
  auth = {
    authorize: (url) => this.request((id) => ({ t: "auth.authorize", id, url })).then((value) => String(value))
  };
  log = {
    debug: (...args) => this.log.log("debug", ...args),
    info: (...args) => this.log.log("info", ...args),
    warn: (...args) => this.log.log("warn", ...args),
    error: (...args) => this.log.log("error", ...args),
    log: (level, ...args) => {
      this.emit({ t: "log", level, message: args.map(describe).join(" ") });
    }
  };
  forward(device, message) {
    const wire = intoWire(message);
    this.emit(device === void 0 ? { t: "device.send", message: wire } : { t: "device.send", device, message: wire });
  }
  async run() {
    this.reader = this.host.readable.getReader();
    try {
      for await (const line of readLines(this.reader)) {
        const message = this.parse(line);
        if (!message)
          continue;
        if (message.t === "stop") {
          await this.finish(0);
          return;
        }
        this.dispatch(message);
      }
    } catch (err) {
      await this.finish(1, new ExtensionError(`stdin read failed: ${describe(err)}`, "disconnected"));
      return;
    }
    await this.finish(0);
  }
  ensure(id) {
    const existing = this.devices_.get(id);
    if (existing)
      return existing;
    const fresh = new DeviceImpl(id, this);
    this.devices_.set(id, fresh);
    return fresh;
  }
  parse(line) {
    try {
      return JSON.parse(line);
    } catch (err) {
      this.log.error(`unparseable line from host: ${describe(err)}`);
      return void 0;
    }
  }
  dispatch(message) {
    switch (message.t) {
      case "hello": {
        this.helloApi = message.api;
        this.helloWebapp = message.webapp;
        this.helloDataDir = message.dataDir;
        this.begin();
        return;
      }
      case "device.connected": {
        const device = this.ensure(message.device);
        device.name = message.name;
        device.config = { ...message.config };
        device.active = message.active;
        device.connected = true;
        this.announce({ type: "connected", device });
        return;
      }
      case "device.disconnected": {
        const device = this.devices_.get(message.device);
        if (!device)
          return;
        device.connected = false;
        device.active = false;
        this.announce({ type: "disconnected", device });
        return;
      }
      case "device.active": {
        const device = this.ensure(message.device);
        device.active = message.active;
        this.announce({ type: "active", device });
        return;
      }
      case "device.message": {
        const device = this.ensure(message.device);
        const forwarded = this.guard(() => fromWire(message.message));
        if (!forwarded)
          return;
        for (const listener of [...this.onMessage])
          this.guard(() => listener(device, forwarded));
        return;
      }
      case "config.changed": {
        const device = this.ensure(message.device);
        const next = { ...device.config };
        if (message.value === null)
          delete next[message.key];
        else
          next[message.key] = message.value;
        device.config = next;
        for (const listener of [...this.onConfig]) {
          this.guard(() => listener(device, message.key, message.value));
        }
        return;
      }
      case "reply": {
        const waiting = this.pending.get(message.id);
        if (!waiting)
          return;
        this.pending.delete(message.id);
        if (message.ok)
          waiting.resolve(message.value);
        else
          waiting.reject(new ExtensionError(message.error, "host-error"));
        return;
      }
    }
  }
  begin() {
    if (this.started)
      return;
    this.started = true;
    let starting;
    try {
      starting = this.spec.start(this);
    } catch (err) {
      this.abortStart(err);
      return;
    }
    void Promise.resolve(starting).then(() => this.emit({ t: "ready" }), (err) => this.abortStart(err));
  }
  abortStart(err) {
    this.log.error(`start failed: ${describe(err)}`);
    void this.finish(1, new ExtensionError(describe(err), "host-error"));
  }
  announce(event) {
    for (const listener of [...this.onDevice])
      this.guard(() => listener(event));
  }
  guard(run) {
    try {
      return run();
    } catch (err) {
      this.log.error(describe(err));
      return void 0;
    }
  }
  emit(message) {
    this.writer.write(message).catch((err) => {
      void this.finish(1, new ExtensionError(`stdout write failed: ${describe(err)}`, "write-failed"));
    });
  }
  request(build2) {
    if (this.settled) {
      const advice = "kv and auth cannot be reached once shutdown has begun, so persist eagerly rather than from stop";
      return Promise.reject(new ExtensionError(`${this.settled.message}; ${advice}`, this.settled.kind));
    }
    const id = String(this.nextRequestId++);
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.writer.write(build2(id)).catch((err) => {
        if (!this.pending.delete(id))
          return;
        reject(new ExtensionError(`stdout write failed: ${describe(err)}`, "write-failed"));
      });
    });
  }
  finish(code, reason) {
    this.finishing ??= this.shutdown(code, reason);
    return this.finishing;
  }
  async shutdown(code, reason) {
    const failure = reason ?? new ExtensionError("the host closed the connection", "disconnected");
    this.settled = failure;
    await this.reader?.cancel().catch(() => void 0);
    for (const waiting of [...this.pending.values()])
      waiting.reject(failure);
    this.pending.clear();
    try {
      await this.spec.stop?.();
    } catch (err) {
      await this.writer.write({ t: "log", level: "error", message: `stop failed: ${describe(err)}` }).catch(() => void 0);
    }
    await this.writer.close();
    this.host.exit(code);
  }
};

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/index.js
function defineExtension(spec, host = denoHost()) {
  return new ExtensionRuntime(spec, host).run();
}

// extension/http.ts
var clientResolved = false;
var httpClient;
async function keychainClient() {
  if (clientResolved) return httpClient;
  clientResolved = true;
  if (Deno.build.os !== "darwin") return void 0;
  try {
    const out = await new Deno.Command("security", {
      args: ["find-certificate", "-a", "-p"],
      stdout: "piped",
      stderr: "null"
    }).output();
    if (!out.success) return void 0;
    const caCerts = new TextDecoder().decode(out.stdout).split(/(?=-----BEGIN CERTIFICATE-----)/).map((block) => block.trim()).filter((block) => block.startsWith("-----BEGIN CERTIFICATE-----"));
    if (caCerts.length > 0) httpClient = Deno.createHttpClient({ caCerts });
  } catch {
    httpClient = void 0;
  }
  return httpClient;
}
function closeHttpClient() {
  httpClient?.close();
}
function describeError(err) {
  const cause = err?.cause?.message;
  return cause ? `${String(err)} cause: ${cause}` : String(err);
}

// extension/inputcount.ts
var POLL_MS = 5e3;
var HEARTBEAT_MS = 3e4;
function countsPath() {
  const home = Deno.env.get("HOME");
  return home ? `${home}/Library/Application Support/dash-inputcount/counts.json` : null;
}
function parse(text2) {
  let body;
  try {
    body = JSON.parse(text2);
  } catch {
    return { kind: "input-counts", status: "unavailable" };
  }
  if (body.status === "needs-permission") return { kind: "input-counts", status: "needs-permission" };
  const keys = body.keys;
  const scrollPoints = body.scrollPoints;
  if (typeof keys !== "number" || typeof scrollPoints !== "number") {
    return { kind: "input-counts", status: "unavailable" };
  }
  return {
    kind: "input-counts",
    status: "counting",
    at: typeof body.at === "number" ? body.at : Date.now(),
    keys: Math.max(0, keys),
    scrollPoints: Math.max(0, scrollPoints)
  };
}
function same(a, b) {
  if (a.status !== b.status) return false;
  if (a.status !== "counting" || b.status !== "counting") return true;
  return a.keys === b.keys && a.scrollPoints === b.scrollPoints;
}
function startInputCounts(ctx, onChange) {
  let state = { kind: "input-counts", status: "unavailable" };
  let announced = "";
  let sentAt = 0;
  const path = countsPath();
  const poll = async () => {
    if (!path) return;
    let next;
    try {
      next = parse(await Deno.readTextFile(path));
    } catch {
      next = { kind: "input-counts", status: "unavailable" };
    }
    if (next.status !== announced) {
      announced = next.status;
      if (next.status === "needs-permission") {
        ctx.log.warn("the input odometer is installed but input monitoring is not granted to it;", path);
      } else if (next.status === "unavailable") {
        ctx.log.info("no input odometer at", path, "- run `bun run install-inputcount` to add one");
      } else {
        ctx.log.info("input odometer reading", next.keys, "keys");
      }
    }
    const changed = !same(state, next);
    state = next;
    if (!changed && Date.now() - sentAt < HEARTBEAT_MS) return;
    sentAt = Date.now();
    onChange(next);
  };
  void poll();
  const timer2 = setInterval(() => void poll(), POLL_MS);
  return {
    current: () => state,
    stop: () => clearInterval(timer2)
  };
}

// extension/painting.ts
var CHECK_MS = 15 * 6e4;
var CURRENT_KEY = "painting-current";
var HISTORY_KEY = "painting-history";
var HISTORY = 365;
var PREVIOUS_KEY = "painting-previous";
var PREVIOUS = 3;
var BLURB_MAX = 420;
var TRIES_PER_SOURCE = 8;
var SCREEN_W = 800;
var SCREEN_H = 480;
var MIN_ASPECT = 1.2;
var MAX_ASPECT = 2.4;
var MAX_UPSCALE = 1.25;
var MAX_BYTES = 9e5;
var UA = "dash-deskthing (https://github.com/e-thanshan/my-deskthing)";
async function get(url, init = {}) {
  const res = await fetch(url, {
    ...init,
    client: await keychainClient(),
    headers: { "user-agent": UA, ...init.headers },
    signal: AbortSignal.timeout(2e4)
  });
  if (!res.ok) {
    await res.body?.cancel();
    throw new Error(`${res.status} ${res.statusText} from ${new URL(url).host}`);
  }
  return res;
}
async function getJson(url, init) {
  return (await get(url, init)).json();
}
function isRecord(value) {
  return !!value && typeof value === "object";
}
function str(value) {
  return typeof value === "string" ? value.trim() : "";
}
function num(value) {
  const n = typeof value === "string" ? Number(value) : value;
  return typeof n === "number" && Number.isFinite(n) && n > 0 ? n : void 0;
}
var ENTITIES = {
  amp: "&",
  lt: "<",
  gt: ">",
  quot: '"',
  apos: "'",
  nbsp: " ",
  lsquo: "\u2018",
  rsquo: "\u2019",
  ldquo: "\u201C",
  rdquo: "\u201D",
  ndash: "\u2013",
  mdash: "\u2014",
  hellip: "\u2026"
};
var TAG = /<[^>]*>/g;
function decodeEntities(text2) {
  return text2.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (whole, code) => {
    if (code[0] !== "#") return ENTITIES[code.toLowerCase()] ?? whole;
    const point = code[1] === "x" || code[1] === "X" ? parseInt(code.slice(2), 16) : Number(code.slice(1));
    return point > 0 && point <= 1114111 ? String.fromCodePoint(point) : whole;
  });
}
function cleanText(value) {
  return decodeEntities(str(value).replace(TAG, " ")).replace(TAG, " ").replace(/\s+/g, " ").trim();
}
function clip(text2, max = BLURB_MAX) {
  if (text2.length <= max) return text2;
  const cut = text2.slice(0, max + 1);
  const end = Math.max(cut.lastIndexOf(". "), cut.lastIndexOf("! "), cut.lastIndexOf("? "));
  if (end > max * 0.4) return cut.slice(0, end + 1);
  return `${cut.slice(0, cut.lastIndexOf(" ", max))}\u2026`;
}
function randInt(n) {
  return Math.floor(Math.random() * n);
}
function shuffle(items) {
  for (let i = items.length - 1; i > 0; i--) {
    const j = randInt(i + 1);
    [items[i], items[j]] = [items[j], items[i]];
  }
  return items;
}
async function* artInstitute() {
  const url = "https://api.artic.edu/api/v1/artworks/search";
  const headers = { "content-type": "application/json", "aic-user-agent": UA };
  const filter = [
    { term: { is_public_domain: true } },
    { term: { artwork_type_id: 1 } },
    { exists: { field: "image_id" } }
  ];
  const shapes = [
    { query: { bool: { filter, must: [{ match: { subject_titles: "landscapes" } }] } } },
    { q: "landscape", query: { bool: { filter } } }
  ];
  const ask = (shape2, page, limit) => getJson(url, {
    method: "POST",
    headers,
    body: JSON.stringify({
      ...shape2,
      fields: [
        "id",
        "title",
        "artist_title",
        "artist_display",
        "date_display",
        "image_id",
        "thumbnail",
        "short_description",
        "description"
      ],
      limit,
      page
    })
  });
  const LIMIT = 50;
  let shape;
  let total;
  for (const candidate of shapes) {
    const head = await ask(candidate, 1, 1);
    total = isRecord(head) && isRecord(head.pagination) ? num(head.pagination.total) : void 0;
    if (total) {
      shape = candidate;
      break;
    }
  }
  if (!shape || !total) return;
  const pages = Math.max(1, Math.min(Math.ceil(total / LIMIT), Math.floor(1e4 / LIMIT)));
  const body = await ask(shape, 1 + randInt(pages), LIMIT);
  if (!isRecord(body) || !Array.isArray(body.data)) return;
  const iiif = isRecord(body.config) && str(body.config.iiif_url) || "https://www.artic.edu/iiif/2";
  for (const row of shuffle(body.data.filter(isRecord))) {
    const imageId = str(row.image_id);
    if (!imageId) continue;
    const thumb = isRecord(row.thumbnail) ? row.thumbnail : {};
    yield {
      id: `aic:${row.id}`,
      title: str(row.title),
      artist: str(row.artist_title) || str(row.artist_display).split("\n")[0],
      date: str(row.date_display),
      museum: "Art Institute of Chicago",
      link: `https://www.artic.edu/artworks/${row.id}`,
      blurb: clip(cleanText(row.short_description) || cleanText(row.description)),
      // 843 is the width the iiif server keeps cached, and the one it asks clients to use
      image: `${iiif}/${imageId}/full/843,/0/default.jpg`,
      headers: { "aic-user-agent": UA },
      width: num(thumb.width),
      height: num(thumb.height)
    };
  }
}
var LANDSCAPE_WORDS = /\b(landscapes?|views?|vistas?|scenery|rivers?|lakes?|mountains?|valleys?|hills?|coasts?|shores?|seas?|seascapes?|harbou?rs?|bays?|forests?|woods?|woodlands?|fields?|meadows?|pastures?|marsh(es)?|islands?|waterfalls?|cascades?|sunsets?|sunrise|twilight|moonlight|winter|snow|storms?|clouds?|sky|countryside|gardens?|streams?|brooks?|cliffs?|plains?|dunes?|beach(es)?|village)\b/i;
var NOT_LANDSCAPE = /\b(calligraphy|portrait|still life|inscription|colophon|sutra)\b/i;
function readsAsLandscape(row) {
  const title = str(row.title);
  if (NOT_LANDSCAPE.test(title)) return false;
  const alternates = Array.isArray(row.alternate_titles) ? row.alternate_titles.map(str) : [];
  const annotation = isRecord(row.images) ? str(row.images.annotation) : "";
  return [title, ...alternates, annotation, cleanText(row.description)].some((text2) => LANDSCAPE_WORDS.test(text2));
}
async function* cleveland(deps) {
  const base = "https://openaccess-api.clevelandart.org/api/artworks/?q=landscape&type=Painting&has_image=1&cc0=1";
  const head = await getJson(`${base}&limit=1`);
  const total = isRecord(head) && isRecord(head.info) ? num(head.info.total) : void 0;
  if (!total) return;
  const LIMIT = 25;
  const body = await getJson(`${base}&limit=${LIMIT}&skip=${randInt(Math.max(1, total - LIMIT))}`);
  if (!isRecord(body) || !Array.isArray(body.data)) return;
  for (const row of shuffle(body.data.filter(isRecord))) {
    const web = isRecord(row.images) && isRecord(row.images.web) ? row.images.web : null;
    const image = web ? str(web.url) : "";
    if (!image) continue;
    if (!readsAsLandscape(row)) {
      deps.log.debug("skip", `cma:${row.id}`, "not a landscape", `(${str(row.title)})`);
      continue;
    }
    const creator = Array.isArray(row.creators) ? row.creators.find(isRecord) : void 0;
    yield {
      id: `cma:${row.id}`,
      title: str(row.title),
      // descriptions read "Thomas Cole (American, 1801-1848)"
      artist: str(creator?.description).replace(/\s*\(.*\)\s*$/, ""),
      date: str(row.creation_date),
      museum: "Cleveland Museum of Art",
      link: str(row.url),
      blurb: clip(cleanText(row.description) || cleanText(row.did_you_know)),
      image,
      width: num(web?.width),
      height: num(web?.height)
    };
  }
}
function smkName(maker) {
  const fore = str(maker?.creator_forename);
  const sur = str(maker?.creator_surname);
  if (fore && sur) return `${fore} ${sur}`;
  const parts = str(maker?.creator).split(", ");
  return parts.length === 2 ? `${parts[1]} ${parts[0]}` : str(maker?.creator);
}
function englishTitle(row) {
  const titles = Array.isArray(row.titles) ? row.titles.filter(isRecord) : [];
  return str(titles.find((t) => /^(en|engelsk)/i.test(str(t.language)))?.title);
}
function monochrome(row) {
  const colors = Array.isArray(row.colors) ? row.colors.map(str).filter((c) => /^#[0-9a-f]{6}$/i.test(c)) : [];
  return colors.length > 0 && colors.every((c) => {
    const [r, g, b] = [1, 3, 5].map((i) => parseInt(c.slice(i, i + 2), 16));
    return Math.max(r, g, b) - Math.min(r, g, b) <= 12;
  });
}
function anyTitle(row) {
  const first = Array.isArray(row.titles) ? row.titles.find(isRecord) : void 0;
  return str(first?.title);
}
async function* smk(deps) {
  const ask = (keys, kind, offset, rows) => getJson(
    `https://api.smk.dk/api/v1/art/search/?keys=${encodeURIComponent(keys)}&filters=${encodeURIComponent(`[has_image:true],[public_domain:true],[object_names:${kind}]`)}&offset=${offset}&rows=${rows}&lang=en`
  );
  let found = 0;
  let shape;
  for (const candidate of [
    ["landskab", "maleri"],
    ["landscape", "painting"],
    ["landskab", "painting"],
    ["landscape", "maleri"]
  ]) {
    const head = await ask(...candidate, 0, 1);
    found = isRecord(head) && num(head.found) || 0;
    if (found) {
      shape = candidate;
      break;
    }
  }
  if (!shape) return;
  deps.log.debug("smk search", shape.join(" / "), "finds", found);
  const ROWS = 25;
  const body = await ask(...shape, randInt(Math.max(1, found - ROWS)), ROWS);
  const items = isRecord(body) && Array.isArray(body.items) ? body.items.filter(isRecord) : [];
  const ordered = shuffle(items).sort((a, b) => Number(!!englishTitle(b)) - Number(!!englishTitle(a)));
  for (const row of ordered) {
    const iiif = str(row.image_iiif_id);
    const image = iiif ? `${iiif}/full/!1280,1280/0/default.jpg` : str(row.image_thumbnail);
    if (!image) continue;
    const objectNumber = str(row.object_number);
    if (monochrome(row)) {
      deps.log.debug("skip", `smk:${objectNumber}`, "black and white photograph", JSON.stringify(row.colors));
      continue;
    }
    const maker = Array.isArray(row.production) ? row.production.find(isRecord) : void 0;
    const artist = Array.isArray(row.artist) ? str(row.artist[0]) : "";
    const made = Array.isArray(row.production_date) ? row.production_date.find(isRecord) : void 0;
    yield {
      id: `smk:${objectNumber || str(row.id)}`,
      title: englishTitle(row) || anyTitle(row),
      artist: artist || smkName(maker),
      date: str(made?.period),
      museum: "National Gallery of Denmark",
      link: str(row.frontend_url) || (objectNumber ? `https://open.smk.dk/artwork/image/${objectNumber}` : ""),
      blurb: "",
      image,
      width: num(row.image_width),
      height: num(row.image_height)
    };
  }
}
function jpegSize(b) {
  if (b[0] !== 255 || b[1] !== 216) return null;
  let i = 2;
  while (i + 9 < b.length) {
    if (b[i] !== 255) return null;
    const marker = b[i + 1];
    if (marker === 255) {
      i++;
      continue;
    }
    if (marker >= 192 && marker <= 207 && marker !== 196 && marker !== 200 && marker !== 204) {
      return { height: b[i + 5] << 8 | b[i + 6], width: b[i + 7] << 8 | b[i + 8] };
    }
    i += 2 + (b[i + 2] << 8 | b[i + 3]);
  }
  return null;
}
function fits(width, height) {
  const aspect = width / height;
  if (aspect < MIN_ASPECT) return `too tall (${width}x${height})`;
  if (aspect > MAX_ASPECT) return `too wide (${width}x${height})`;
  if (Math.max(SCREEN_W / width, SCREEN_H / height) > MAX_UPSCALE) return `too small (${width}x${height})`;
  return null;
}
function toBase642(bytes) {
  let s = "";
  for (let i = 0; i < bytes.length; i += 32768) s += String.fromCharCode(...bytes.subarray(i, i + 32768));
  return btoa(s);
}
async function download(c) {
  const res = await get(c.image, { headers: c.headers });
  const length = Number(res.headers.get("content-length") ?? "0");
  if (length > MAX_BYTES) {
    await res.body?.cancel();
    return `too heavy (${length} bytes)`;
  }
  const bytes = new Uint8Array(await res.arrayBuffer());
  if (bytes.length > MAX_BYTES) return `too heavy (${bytes.length} bytes)`;
  const size2 = jpegSize(bytes);
  if (!size2) return `not a readable jpeg (${res.headers.get("content-type") ?? "no type"})`;
  return fits(size2.width, size2.height) ?? { mime: "image/jpeg", bytes };
}
function localDay(at = /* @__PURE__ */ new Date()) {
  const pad = (n) => String(n).padStart(2, "0");
  return `${at.getFullYear()}-${pad(at.getMonth() + 1)}-${pad(at.getDate())}`;
}
var SOURCES = ["aic", "cma", "smk"];
function source(key, deps) {
  if (key === "aic") return artInstitute();
  if (key === "cma") return cleveland(deps);
  return smk(deps);
}
async function pickPainting(day, seen, deps, { only, offset = 0 } = {}) {
  const [y, m, d] = day.split("-").map(Number);
  const first = (Math.floor(Date.UTC(y, m - 1, d) / 864e5) + offset) % SOURCES.length;
  const order = only ? [only] : SOURCES.map((_, i) => SOURCES[(first + i) % SOURCES.length]);
  for (const key of order) {
    let tries = 0;
    try {
      for await (const c of source(key, deps)) {
        if (tries++ >= TRIES_PER_SOURCE) break;
        if (seen.has(c.id) || !c.title) continue;
        const early = c.width && c.height ? fits(c.width, c.height) : null;
        if (early) {
          deps.log.debug("skip", c.id, early);
          continue;
        }
        let got;
        try {
          got = await download(c);
        } catch (err) {
          deps.log.debug("skip", c.id, describeError(err));
          continue;
        }
        if (typeof got === "string") {
          deps.log.debug("skip", c.id, got);
          continue;
        }
        return {
          kind: "painting",
          day,
          id: c.id,
          title: c.title,
          artist: c.artist,
          date: c.date,
          museum: c.museum,
          link: c.link,
          blurb: c.blurb,
          mime: got.mime,
          data: toBase642(got.bytes)
        };
      }
      deps.log.warn("no fitting painting from", key, "after", tries, "candidates");
    } catch (err) {
      deps.log.warn("painting source", key, "failed:", describeError(err));
    }
  }
  return null;
}
function toPainting(value) {
  if (!isRecord(value) || value.kind !== "painting") return null;
  const fields = ["day", "id", "title", "artist", "date", "museum", "mime", "data"];
  if (!fields.every((k) => typeof value[k] === "string")) return null;
  const v = value;
  return {
    kind: "painting",
    day: v.day,
    id: v.id,
    title: v.title,
    artist: v.artist,
    date: v.date,
    museum: v.museum,
    link: str(value.link),
    blurb: str(value.blurb),
    mime: v.mime,
    data: v.data
  };
}
function credit(p) {
  return [p.title, [p.artist, p.date].filter(Boolean).join(", "), p.museum].filter(Boolean).join(" - ");
}
function size(p) {
  return `${p.id}, ${Math.round(p.data.length * 0.75 / 1024)} KB`;
}
function startPainting(ctx, onChange) {
  let current = null;
  let previous = [];
  let busy = false;
  let stopped = false;
  let skips = { day: "", count: 0 };
  const message = () => current ? { ...current, previous: previous.at(-1)?.title ?? null } : null;
  const locked = async (whenBusy, run) => {
    if (busy || stopped) return whenBusy;
    busy = true;
    try {
      return await run();
    } finally {
      busy = false;
    }
  };
  const history = async () => {
    const raw = await ctx.kv.get(HISTORY_KEY);
    return new Set(Array.isArray(raw) ? raw.filter((id) => typeof id === "string") : []);
  };
  const adopt = async (next, keepOutgoing) => {
    if (keepOutgoing && current && current.id !== next.id) {
      const outgoing = current;
      previous = [...previous.filter((p) => p.id !== outgoing.id), outgoing].slice(-PREVIOUS);
    }
    current = next;
    onChange(message(), true);
    await ctx.kv.set(CURRENT_KEY, next);
    await ctx.kv.set(PREVIOUS_KEY, previous);
  };
  const pickInto = async (day, offset) => {
    const seen = await history();
    if (current) seen.add(current.id);
    const next = await pickPainting(day, seen, ctx, { offset });
    if (!next || stopped) return null;
    await adopt(next, true);
    await ctx.kv.set(HISTORY_KEY, [...seen, next.id].slice(-HISTORY));
    return next;
  };
  const tick = () => locked(void 0, async () => {
    const day = localDay();
    if (current?.day === day) return;
    try {
      const next = await pickInto(day, 0);
      if (next) ctx.log.info(`painting for ${day}: ${credit(next)} [${size(next)}]`);
      else ctx.log.warn("no painting found for", day, "- keeping", current?.id ?? "nothing");
    } catch (err) {
      ctx.log.warn("painting check threw", describeError(err));
    }
  });
  const skip = () => locked("busy", async () => {
    const day = localDay();
    skips = { day, count: skips.day === day ? skips.count + 1 : 1 };
    try {
      const next = await pickInto(day, skips.count);
      if (!next) return "failed";
      ctx.log.info(`skipped to: ${credit(next)} [${size(next)}]`);
      return "ok";
    } catch (err) {
      ctx.log.warn("painting skip threw", describeError(err));
      return "failed";
    }
  });
  const back = () => locked("busy", async () => {
    const last = previous.at(-1);
    if (!last) return "none";
    previous = previous.slice(0, -1);
    const restored = { ...last, day: localDay() };
    try {
      await adopt(restored, false);
    } catch (err) {
      ctx.log.warn("could not persist the restored painting", describeError(err));
    }
    ctx.log.info(`back to: ${credit(restored)}`);
    return "ok";
  });
  void (async () => {
    try {
      const cached = toPainting(await ctx.kv.get(CURRENT_KEY));
      const stack = await ctx.kv.get(PREVIOUS_KEY);
      if (Array.isArray(stack)) previous = stack.map(toPainting).filter((p) => p !== null);
      if (cached && !current) {
        current = cached;
        onChange(message(), false);
      }
    } catch (err) {
      ctx.log.warn("could not read the cached painting", describeError(err));
    }
    await tick();
  })();
  const timer2 = setInterval(() => void tick(), CHECK_MS);
  return {
    current: () => current,
    message,
    skip,
    back,
    stop: () => {
      stopped = true;
      clearInterval(timer2);
    }
  };
}

// extension/saved.ts
var SAVED_KEY = "painting-saved";
var SAVED_FILE = "~/dash-paintings.md";
function savedPath() {
  const home = Deno.env.get("HOME");
  return home ? SAVED_FILE.replace("~", home) : null;
}
function entry(p) {
  const byline = [p.artist, p.date].filter(Boolean).join(", ");
  const line = [
    `**${p.title}**${byline ? `, ${byline}` : ""}`,
    p.museum,
    p.link ? `[museum page](${p.link})` : "",
    `saved ${localDay()}`
  ].filter(Boolean).join(" \xB7 ");
  return `- ${line}
${p.blurb ? `  > ${p.blurb}
` : ""}`;
}
async function savePainting(ctx, painting) {
  const path = savedPath();
  if (!path) return "failed";
  const raw = await ctx.kv.get(SAVED_KEY);
  const saved = Array.isArray(raw) ? raw.filter((id) => typeof id === "string") : [];
  if (saved.includes(painting.id)) return "already";
  try {
    try {
      await Deno.writeTextFile(path, "# Saved paintings\n\n", { createNew: true });
    } catch {
    }
    await Deno.writeTextFile(path, entry(painting), { append: true });
  } catch (err) {
    ctx.log.warn("could not save to", path, describeError(err));
    return "failed";
  }
  await ctx.kv.set(SAVED_KEY, [...saved, painting.id]);
  ctx.log.info("saved", credit(painting), "to", path);
  return "saved";
}

// extension/main.ts
var ENDPOINT = "https://api.anthropic.com/api/oauth/usage";
var KEYCHAIN_SERVICE = "Claude Code-credentials";
var POLL_MS2 = 3e5;
var CACHE_KEY = "last-usage";
async function readToken() {
  const out = await new Deno.Command("security", {
    args: ["find-generic-password", "-s", KEYCHAIN_SERVICE, "-w"],
    stdout: "piped",
    stderr: "null"
  }).output();
  if (!out.success) return null;
  try {
    const token = JSON.parse(new TextDecoder().decode(out.stdout))?.claudeAiOauth?.accessToken;
    return typeof token === "string" && token ? token : null;
  } catch {
    return null;
  }
}
function toEpochMs(value) {
  if (typeof value === "number" && Number.isFinite(value)) return value > 1e11 ? value : value * 1e3;
  if (typeof value === "string") {
    const parsed = Date.parse(value);
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
}
function toPct(value) {
  if (typeof value !== "number" || !Number.isFinite(value)) return null;
  return Math.max(0, Math.min(100, value));
}
function isRecord2(value) {
  return !!value && typeof value === "object";
}
function modelName(row) {
  const model = isRecord2(row.scope) ? row.scope.model : null;
  const name = isRecord2(model) ? model.display_name : null;
  return typeof name === "string" && name ? name : null;
}
function build(row, label) {
  const pct = toPct(row.percent);
  if (pct == null) return null;
  return {
    pct,
    resetsAt: toEpochMs(row.resets_at),
    severity: typeof row.severity === "string" ? row.severity : "normal",
    label
  };
}
function fromLimits(body) {
  const limits = isRecord2(body) ? body.limits : null;
  if (!Array.isArray(limits)) return null;
  const rows = limits.filter(isRecord2);
  const session = rows.find((row) => row.kind === "session");
  const scoped = rows.find((row) => row.kind === "weekly_scoped" && modelName(row));
  const all = rows.find((row) => row.kind === "weekly_all");
  const weeklyLabel = scoped ? modelName(scoped).slice(0, 5).toUpperCase() : "7D";
  return {
    session: session ? build(session, "5H") : null,
    weekly: scoped ? build(scoped, weeklyLabel) : all ? build(all, "7D") : null
  };
}
function fromRootWindows(body) {
  const root = isRecord2(body) ? body : {};
  const pick = (value, label) => {
    if (!isRecord2(value)) return null;
    const pct = toPct(value.utilization);
    if (pct == null) return null;
    return { pct, resetsAt: toEpochMs(value.resets_at), severity: "normal", label };
  };
  return { session: pick(root.five_hour, "5H"), weekly: pick(root.seven_day, "7D") };
}
function toUsage(body) {
  return { kind: "claude-usage", at: Date.now(), ...fromLimits(body) ?? fromRootWindows(body) };
}
function describe2(usage) {
  const one = (window) => {
    if (!window) return "none";
    const resets = window.resetsAt == null ? "no reset" : `resets in ${((window.resetsAt - Date.now()) / 36e5).toFixed(1)}h`;
    return `${window.label} ${window.pct.toFixed(0)}% ${window.severity} ${resets}`;
  };
  return `session: ${one(usage.session)}; weekly: ${one(usage.weekly)}`;
}
var timer;
var input;
var paintings;
defineExtension({
  async start(ctx) {
    let latest = null;
    let announced = false;
    const push = () => {
      if (latest) ctx.broadcast(json(latest));
    };
    const counter = startInputCounts(ctx, (state) => ctx.broadcast(json(state)));
    input = counter;
    const offer = (id) => json({ kind: "painting-offer", id });
    const feed = startPainting(ctx, (painting, fresh) => ctx.broadcast(fresh ? json(painting) : offer(painting.id)));
    paintings = feed;
    ctx.on("device", (event) => {
      if (!event.device.active) return;
      push();
      event.device.send(json(counter.current()));
      const painting = feed.current();
      if (painting) event.device.send(offer(painting.id));
    });
    ctx.on("message", (device, message) => {
      const asked = asJson(message);
      if (asked?.kind === "input-counts-request") {
        device.send(json(counter.current()));
        return;
      }
      if (asked?.kind === "painting-request") {
        const painting = feed.message();
        if (painting && painting.id !== asked.have) device.send(json(painting));
        return;
      }
      const status = (state) => device.send(json({ kind: "painting-status", state }));
      if (asked?.kind === "painting-skip") {
        status("working");
        void feed.skip().then((r) => r !== "ok" && status(r === "busy" ? "busy" : "skip-failed"));
        return;
      }
      if (asked?.kind === "painting-previous") {
        status("working");
        void feed.back().then((r) => r !== "ok" && status(r === "busy" ? "busy" : "no-previous"));
        return;
      }
      if (asked?.kind === "painting-save") {
        const painting = feed.current();
        if (!painting || painting.id !== asked.id) {
          status("save-failed");
          return;
        }
        void savePainting(ctx, painting).then(
          (r) => status(r === "saved" ? "saved" : r === "already" ? "already-saved" : "save-failed")
        );
        return;
      }
      if (asked?.kind !== "claude-usage-request") return;
      if (latest) device.send(json(latest));
    });
    const poll = async () => {
      const token = await readToken();
      if (!token) {
        ctx.log.warn("no claude credentials in the keychain; skipping poll");
        return;
      }
      try {
        const res = await fetch(ENDPOINT, {
          client: await keychainClient(),
          headers: {
            authorization: `Bearer ${token}`,
            "anthropic-beta": "oauth-2025-04-20",
            "content-type": "application/json"
          }
        });
        if (!res.ok) {
          ctx.log.warn("usage fetch failed", res.status, res.statusText);
          return;
        }
        latest = toUsage(await res.json());
        if (!announced) {
          announced = true;
          ctx.log.info(describe2(latest));
        }
        await ctx.kv.set(CACHE_KEY, latest);
        push();
      } catch (err) {
        ctx.log.warn("usage fetch threw", describeError(err));
      }
    };
    const cached = await ctx.kv.get(CACHE_KEY);
    if (cached) {
      latest = cached;
      push();
    }
    await poll();
    timer = setInterval(poll, POLL_MS2);
  },
  stop() {
    clearInterval(timer);
    input?.stop();
    paintings?.stop();
    closeHttpClient();
  }
});
