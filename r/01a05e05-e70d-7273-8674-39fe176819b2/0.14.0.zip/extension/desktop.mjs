// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/host.js
var ExtensionError = class extends Error {
  kind;
  constructor(message, kind) {
    super(message);
    this.kind = kind;
    this.name = "ExtensionError";
  }
};
async function* readLines(reader) {
  const decoder = new TextDecoder();
  let buffered = "";
  try {
    for (; ; ) {
      const { done, value } = await reader.read();
      if (done)
        break;
      buffered += decoder.decode(value, { stream: true });
      for (let cut = buffered.indexOf("\n"); cut >= 0; cut = buffered.indexOf("\n")) {
        const line = buffered.slice(0, cut);
        buffered = buffered.slice(cut + 1);
        if (line.trim().length > 0)
          yield line;
      }
    }
    buffered += decoder.decode();
    if (buffered.trim().length > 0)
      yield buffered;
  } finally {
    reader.releaseLock();
  }
}
var LineWriter = class {
  writer;
  encoder = new TextEncoder();
  tail = Promise.resolve();
  constructor(writable) {
    this.writer = writable.getWriter();
  }
  write(message) {
    const chunk = this.encoder.encode(`${JSON.stringify(message)}
`);
    const written = this.tail.then(() => this.writer.write(chunk));
    this.tail = written.catch(() => void 0);
    return written;
  }
  async close() {
    await this.tail;
    try {
      await this.writer.close();
    } catch {
      this.writer.releaseLock();
    }
  }
};

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/deno.js
function denoHost() {
  const runtime = globalThis.Deno;
  if (!runtime) {
    throw new ExtensionError("extensions run under deno; no Deno global in this process", "no-runtime");
  }
  return {
    readable: runtime.stdin.readable,
    writable: runtime.stdout.writable,
    exit: (code) => runtime.exit(code)
  };
}

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/message.js
function json(data) {
  return { encoding: "json", data };
}
function asJson(message) {
  return message.encoding === "json" ? message.data : void 0;
}
var CHUNK = 32768;
function toBase64(bytes) {
  let latin1 = "";
  for (let i = 0; i < bytes.length; i += CHUNK) {
    latin1 += String.fromCharCode(...bytes.subarray(i, i + CHUNK));
  }
  return btoa(latin1);
}
function fromBase64(data) {
  const latin1 = atob(data);
  const bytes = new Uint8Array(latin1.length);
  for (let i = 0; i < latin1.length; i++)
    bytes[i] = latin1.charCodeAt(i);
  return bytes;
}
function intoWire(message) {
  if (typeof message === "string")
    return { encoding: "text", data: message };
  if (message instanceof Uint8Array)
    return { encoding: "binary", data: toBase64(message) };
  if (message.encoding === "binary")
    return { encoding: "binary", data: toBase64(message.data) };
  return message;
}
function fromWire(message) {
  if (message.encoding === "binary")
    return { encoding: "binary", data: fromBase64(message.data) };
  return message;
}

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/protocol.js
var EXTENSION_API_VERSION = 1;

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/runtime.js
function describe(value) {
  if (typeof value === "string")
    return value;
  if (value instanceof Error)
    return value.stack ?? `${value.name}: ${value.message}`;
  try {
    return JSON.stringify(value) ?? String(value);
  } catch {
    return String(value);
  }
}
var DeviceImpl = class {
  id;
  runtime;
  name = "";
  active = false;
  connected = false;
  config = {};
  constructor(id, runtime) {
    this.id = id;
    this.runtime = runtime;
  }
  send(message) {
    this.runtime.forward(this.id, message);
  }
};
var ExtensionRuntime = class {
  spec;
  host;
  writer;
  devices_ = /* @__PURE__ */ new Map();
  pending = /* @__PURE__ */ new Map();
  onDevice = /* @__PURE__ */ new Set();
  onMessage = /* @__PURE__ */ new Set();
  onConfig = /* @__PURE__ */ new Set();
  nextRequestId = 1;
  started = false;
  finishing;
  settled;
  helloApi = EXTENSION_API_VERSION;
  helloWebapp = { id: "", name: "", version: "" };
  helloDataDir = "";
  reader;
  constructor(spec, host) {
    this.spec = spec;
    this.host = host;
    this.writer = new LineWriter(host.writable);
  }
  get api() {
    return this.helloApi;
  }
  get webapp() {
    return this.helloWebapp;
  }
  get dataDir() {
    return this.helloDataDir;
  }
  get devices() {
    return [...this.devices_.values()].filter((device) => device.connected);
  }
  device(id) {
    return this.ensure(id);
  }
  broadcast(message) {
    this.forward(void 0, message);
  }
  config(device) {
    const id = typeof device === "string" ? device : device.id;
    return this.devices_.get(id)?.config ?? {};
  }
  on(event, listener) {
    if (event === "device") {
      const fn2 = listener;
      this.onDevice.add(fn2);
      return () => this.onDevice.delete(fn2);
    }
    if (event === "message") {
      const fn2 = listener;
      this.onMessage.add(fn2);
      return () => this.onMessage.delete(fn2);
    }
    const fn = listener;
    this.onConfig.add(fn);
    return () => this.onConfig.delete(fn);
  }
  kv = {
    get: (key) => this.request((id) => ({ t: "kv.get", id, key })).then((value) => value === null ? void 0 : value),
    set: (key, value) => this.request((id) => ({ t: "kv.set", id, key, value })).then(() => void 0),
    delete: (key) => this.request((id) => ({ t: "kv.delete", id, key })).then(() => void 0),
    list: () => this.request((id) => ({ t: "kv.list", id })).then((value) => value ?? [])
  };
  auth = {
    authorize: (url) => this.request((id) => ({ t: "auth.authorize", id, url })).then((value) => String(value))
  };
  log = {
    debug: (...args) => this.log.log("debug", ...args),
    info: (...args) => this.log.log("info", ...args),
    warn: (...args) => this.log.log("warn", ...args),
    error: (...args) => this.log.log("error", ...args),
    log: (level, ...args) => {
      this.emit({ t: "log", level, message: args.map(describe).join(" ") });
    }
  };
  forward(device, message) {
    const wire = intoWire(message);
    this.emit(device === void 0 ? { t: "device.send", message: wire } : { t: "device.send", device, message: wire });
  }
  async run() {
    this.reader = this.host.readable.getReader();
    try {
      for await (const line of readLines(this.reader)) {
        const message = this.parse(line);
        if (!message)
          continue;
        if (message.t === "stop") {
          await this.finish(0);
          return;
        }
        this.dispatch(message);
      }
    } catch (err) {
      await this.finish(1, new ExtensionError(`stdin read failed: ${describe(err)}`, "disconnected"));
      return;
    }
    await this.finish(0);
  }
  ensure(id) {
    const existing = this.devices_.get(id);
    if (existing)
      return existing;
    const fresh = new DeviceImpl(id, this);
    this.devices_.set(id, fresh);
    return fresh;
  }
  parse(line) {
    try {
      return JSON.parse(line);
    } catch (err) {
      this.log.error(`unparseable line from host: ${describe(err)}`);
      return void 0;
    }
  }
  dispatch(message) {
    switch (message.t) {
      case "hello": {
        this.helloApi = message.api;
        this.helloWebapp = message.webapp;
        this.helloDataDir = message.dataDir;
        this.begin();
        return;
      }
      case "device.connected": {
        const device = this.ensure(message.device);
        device.name = message.name;
        device.config = { ...message.config };
        device.active = message.active;
        device.connected = true;
        this.announce({ type: "connected", device });
        return;
      }
      case "device.disconnected": {
        const device = this.devices_.get(message.device);
        if (!device)
          return;
        device.connected = false;
        device.active = false;
        this.announce({ type: "disconnected", device });
        return;
      }
      case "device.active": {
        const device = this.ensure(message.device);
        device.active = message.active;
        this.announce({ type: "active", device });
        return;
      }
      case "device.message": {
        const device = this.ensure(message.device);
        const forwarded = this.guard(() => fromWire(message.message));
        if (!forwarded)
          return;
        for (const listener of [...this.onMessage])
          this.guard(() => listener(device, forwarded));
        return;
      }
      case "config.changed": {
        const device = this.ensure(message.device);
        const next = { ...device.config };
        if (message.value === null)
          delete next[message.key];
        else
          next[message.key] = message.value;
        device.config = next;
        for (const listener of [...this.onConfig]) {
          this.guard(() => listener(device, message.key, message.value));
        }
        return;
      }
      case "reply": {
        const waiting = this.pending.get(message.id);
        if (!waiting)
          return;
        this.pending.delete(message.id);
        if (message.ok)
          waiting.resolve(message.value);
        else
          waiting.reject(new ExtensionError(message.error, "host-error"));
        return;
      }
    }
  }
  begin() {
    if (this.started)
      return;
    this.started = true;
    let starting;
    try {
      starting = this.spec.start(this);
    } catch (err) {
      this.abortStart(err);
      return;
    }
    void Promise.resolve(starting).then(() => this.emit({ t: "ready" }), (err) => this.abortStart(err));
  }
  abortStart(err) {
    this.log.error(`start failed: ${describe(err)}`);
    void this.finish(1, new ExtensionError(describe(err), "host-error"));
  }
  announce(event) {
    for (const listener of [...this.onDevice])
      this.guard(() => listener(event));
  }
  guard(run) {
    try {
      return run();
    } catch (err) {
      this.log.error(describe(err));
      return void 0;
    }
  }
  emit(message) {
    this.writer.write(message).catch((err) => {
      void this.finish(1, new ExtensionError(`stdout write failed: ${describe(err)}`, "write-failed"));
    });
  }
  request(build2) {
    if (this.settled) {
      const advice = "kv and auth cannot be reached once shutdown has begun, so persist eagerly rather than from stop";
      return Promise.reject(new ExtensionError(`${this.settled.message}; ${advice}`, this.settled.kind));
    }
    const id = String(this.nextRequestId++);
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.writer.write(build2(id)).catch((err) => {
        if (!this.pending.delete(id))
          return;
        reject(new ExtensionError(`stdout write failed: ${describe(err)}`, "write-failed"));
      });
    });
  }
  finish(code, reason) {
    this.finishing ??= this.shutdown(code, reason);
    return this.finishing;
  }
  async shutdown(code, reason) {
    const failure = reason ?? new ExtensionError("the host closed the connection", "disconnected");
    this.settled = failure;
    await this.reader?.cancel().catch(() => void 0);
    for (const waiting of [...this.pending.values()])
      waiting.reject(failure);
    this.pending.clear();
    try {
      await this.spec.stop?.();
    } catch (err) {
      await this.writer.write({ t: "log", level: "error", message: `stop failed: ${describe(err)}` }).catch(() => void 0);
    }
    await this.writer.close();
    this.host.exit(code);
  }
};

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/index.js
function defineExtension(spec, host = denoHost()) {
  return new ExtensionRuntime(spec, host).run();
}

// extension/main.ts
var ENDPOINT = "https://api.anthropic.com/api/oauth/usage";
var KEYCHAIN_SERVICE = "Claude Code-credentials";
var POLL_MS = 3e5;
var CACHE_KEY = "last-usage";
async function readToken() {
  const out = await new Deno.Command("security", {
    args: ["find-generic-password", "-s", KEYCHAIN_SERVICE, "-w"],
    stdout: "piped",
    stderr: "null"
  }).output();
  if (!out.success) return null;
  try {
    const token = JSON.parse(new TextDecoder().decode(out.stdout))?.claudeAiOauth?.accessToken;
    return typeof token === "string" && token ? token : null;
  } catch {
    return null;
  }
}
function toEpochMs(value) {
  if (typeof value === "number" && Number.isFinite(value)) return value > 1e11 ? value : value * 1e3;
  if (typeof value === "string") {
    const parsed = Date.parse(value);
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
}
function toPct(value) {
  if (typeof value !== "number" || !Number.isFinite(value)) return null;
  return Math.max(0, Math.min(100, value));
}
function isRecord(value) {
  return !!value && typeof value === "object";
}
function modelName(row) {
  const model = isRecord(row.scope) ? row.scope.model : null;
  const name = isRecord(model) ? model.display_name : null;
  return typeof name === "string" && name ? name : null;
}
function build(row, label) {
  const pct = toPct(row.percent);
  if (pct == null) return null;
  return {
    pct,
    resetsAt: toEpochMs(row.resets_at),
    severity: typeof row.severity === "string" ? row.severity : "normal",
    label
  };
}
function fromLimits(body) {
  const limits = isRecord(body) ? body.limits : null;
  if (!Array.isArray(limits)) return null;
  const rows = limits.filter(isRecord);
  const session = rows.find((row) => row.kind === "session");
  const scoped = rows.find((row) => row.kind === "weekly_scoped" && modelName(row));
  const all = rows.find((row) => row.kind === "weekly_all");
  const weeklyLabel = scoped ? modelName(scoped).slice(0, 5).toUpperCase() : "7D";
  return {
    session: session ? build(session, "5H") : null,
    weekly: scoped ? build(scoped, weeklyLabel) : all ? build(all, "7D") : null
  };
}
function fromRootWindows(body) {
  const root = isRecord(body) ? body : {};
  const pick = (value, label) => {
    if (!isRecord(value)) return null;
    const pct = toPct(value.utilization);
    if (pct == null) return null;
    return { pct, resetsAt: toEpochMs(value.resets_at), severity: "normal", label };
  };
  return { session: pick(root.five_hour, "5H"), weekly: pick(root.seven_day, "7D") };
}
function toUsage(body) {
  return { kind: "claude-usage", at: Date.now(), ...fromLimits(body) ?? fromRootWindows(body) };
}
function describe2(usage) {
  const one = (window) => {
    if (!window) return "none";
    const resets = window.resetsAt == null ? "no reset" : `resets in ${((window.resetsAt - Date.now()) / 36e5).toFixed(1)}h`;
    return `${window.label} ${window.pct.toFixed(0)}% ${window.severity} ${resets}`;
  };
  return `session: ${one(usage.session)}; weekly: ${one(usage.weekly)}`;
}
var timer;
defineExtension({
  async start(ctx) {
    let latest = null;
    let announced = false;
    const push = () => {
      if (latest) ctx.broadcast(json(latest));
    };
    ctx.on("device", (event) => {
      if (event.device.active) push();
    });
    ctx.on("message", (device, message) => {
      const asked = asJson(message);
      if (asked?.kind !== "claude-usage-request") return;
      if (latest) device.send(json(latest));
    });
    const poll = async () => {
      const token = await readToken();
      if (!token) {
        ctx.log.warn("no claude credentials in the keychain; skipping poll");
        return;
      }
      try {
        const res = await fetch(ENDPOINT, {
          headers: {
            authorization: `Bearer ${token}`,
            "anthropic-beta": "oauth-2025-04-20",
            "content-type": "application/json"
          }
        });
        if (!res.ok) {
          ctx.log.warn("usage fetch failed", res.status, res.statusText);
          return;
        }
        latest = toUsage(await res.json());
        if (!announced) {
          announced = true;
          ctx.log.info(describe2(latest));
        }
        await ctx.kv.set(CACHE_KEY, latest);
        push();
      } catch (err) {
        ctx.log.warn("usage fetch threw", err);
      }
    };
    const cached = await ctx.kv.get(CACHE_KEY);
    if (cached) {
      latest = cached;
      push();
    }
    await poll();
    timer = setInterval(poll, POLL_MS);
  },
  stop() {
    clearInterval(timer);
  }
});
